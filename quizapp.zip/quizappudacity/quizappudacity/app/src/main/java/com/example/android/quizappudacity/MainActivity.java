package com.example.android.quizappudacity;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.Gravity;
import android.view.View;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    EditText q1;//ques1
    EditText q2;//ques2
    RadioButton q3ob;//ques3
    CheckBox q4oa;
    CheckBox q4ob;
    CheckBox q4oc;
    EditText q5;
    RadioButton q6oa;
    int sq1;  //score_question_1
    int sq2;
    int sq3;
    int sq4;
    int sq5;
    int sq6;
    String resultsDisplay = null;
    int finalscore = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);
    }

    public void submit(View v) {
        q1 = (EditText) findViewById(R.id.q1);
        if (q1.getText().toString().toLowerCase().equals("drawable")) {
            sq1 = 1;
        } else {
            sq1 = 0;
        }
        q2 = (EditText) findViewById(R.id.q2);
        if (q2.getText().toString().toLowerCase().equals("google")) {
            sq2 = 1;
        } else {
            sq2 = 0;
        }
        Boolean answer3;
        q3ob = (RadioButton) findViewById(R.id.q3ob);
        answer3 = q3ob.isChecked();
        if (answer3) {
            sq3 = 1;
        } else {
            sq3 = 0;
        }
        q4oa = (CheckBox) findViewById(R.id.q4oa);
        q4ob = (CheckBox) findViewById(R.id.q4ob);
        q4oc = (CheckBox) findViewById(R.id.q4oc);
        Boolean answer4a = q4oa.isChecked();
        Boolean answer4b = q4ob.isChecked();
        Boolean answer4c = q4oc.isChecked();
        if (answer4a && answer4b && answer4c) {
            sq4 = 1;
        } else {
            sq4 = 0;
        }
        q5 = (EditText) findViewById(R.id.q5);
        String answer5 = q5.getText().toString().toLowerCase();
        if (answer5.equals("strings")) {
            sq5 = 1;
        } else {
            sq5 = 0;
        }
        Boolean answer6;
        q6oa = (RadioButton) findViewById(R.id.q6oa);
        answer6 = q6oa.isChecked();
        if (answer6) {
            sq6 = 1;
        } else {
            sq6 = 0;
        }
        finalscore = sq1 + sq2 + sq3 + sq4 + sq5 + sq6;
        if (finalscore == 6) {
            resultsDisplay = "Perfect! You scored 6 out of 6";
        } else {
            resultsDisplay = "Try again. You scored " + finalscore + " out of 6";
        }
        int duration = Toast.LENGTH_LONG;
        Toast toast = Toast.makeText(this, resultsDisplay, duration);
        toast.setGravity(Gravity.CENTER, 0, 0);
        toast.show();
    }
}